// Configuration intégrée : rien à saisir à l'installation, comme pour
// l'extension d'adhésion aux groupes.
self.FCP_CONFIG = {
  apiBase: 'https://post.pulserecipe.com',
  // AUTOMATION_API_KEY du serveur, en-tête X-API-Key.
  apiKey: '',
  // Langue de rédaction de l'article réécrit.
  language: 'fr',
  // Vide = tous les profils actifs reçoivent un post. Renseigner pour
  // restreindre la diffusion : ["cmxxxx", "cmyyyy"].
  profileIds: [],
};
